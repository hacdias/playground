// talkingPi animation

$(document).ready(function () {

    var num  = 0;
    var isRunning = false;

    $('#talk-0').fadeIn(500);

    $('.talkBalloon').click(function() {
        if (!window.isRunning) {
            next(false);
        }
    });

    $('.choice-yes').click(function() {
        if (!window.isRunning) {
            next(true);
        }
    });

    $('.choice-no').click(function() {
        var item = $('#talk-' + num);

        item.fadeOut(500, function() {
           $('#talkNo').fadeIn(500);

           $('.choice-yes').fadeOut(500);
           $('.choice-no').fadeOut(500);
        });
    });


    function next(choice) {
        var item = $('#talk-' + num);

        window.isRunning = true;

        if (!choice && item.hasClass('talk-choice'))  {
            window.isRunning = false;
            return false;
        }

        if (choice) {
            $('.choice-yes').fadeOut(500);
            $('.choice-no').fadeOut(500);
        }

        var nextItem = '#talk-' + (num + 1);

        if ($(nextItem).length > 0) {
            item.fadeOut(500, function() {
                num++;
                item = $('#talk-' + num);

                item.fadeIn(500);

                if (item.hasClass('talk-choice') && !choice) {
                    $('.choice-yes').fadeIn(500);
                    $('.choice-no').fadeIn(500);
                }

                window.isRunning = false;

            });
        }

        return false;
    };

});
